<?php 
require ('actions/admin_actions/security-action.php'); 
require ('actions/admin_actions/edit-article-action.php'); 

?> 
<!DOCTYPE html>
<html lang="fr">
<?php 
include'includes/head.php';
?>
<body>
<?php 
include'includes/navbar-admin.php';
?> 

    <br><br>

<section class="container">

        <?php 
                if(isset($errorMsg)){
                    echo "<p class='errorMsg'>".$errorMsg."</p>";
                };
        ?>

<?php 

        if(isset($articleInfos)){}
            ?> 

            
<form method="POST">
  <div class="mb-3">
    <label class="form-label">Titre de l'article</label>
    <input type="text" class="form-control" name="title" autocomplete="off" value="<?= $articleInfos['titre']; ?>">
  </div>

  <div class="mb-3">
  <label class="form-label">Contenu de l'article</label>
  <textarea class="form-control" rows="3" name="content"><?= $articleInfos['contenu']; ?></textarea>
</div>
  <button type="submit" class="btn btn-primary" name="validate">Modifier l'article</button>
</form>


       



</section>



</body>
</html>