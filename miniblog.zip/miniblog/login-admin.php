<?php require('actions/admin_actions/login-action.php');?>
<!DOCTYPE html>
<html lang="fr">
<?php include 'includes/head.php'; ?>
<body>
  <br><br>
    <form class="container" method="POST" action="">

    <?php 
    
        if(isset($errorMsg)){
          echo "<p class='errorMsg'>".$errorMsg."</p>";
        }

    ?>

  <div class="mb-3">
    <label class="form-label">Pseudo Admin</label>
    <input type="text" class="form-control" name="pseudo" autocomplete="off">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Mot de passe</label>
    <input type="password" class="form-control" name="password">
  </div>

  <button type="submit" class="btn btn-primary" name="validate">Se connecter</button>
</form>
</body>
</html> 