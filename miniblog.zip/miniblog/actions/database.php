<?php

// session_start();

try{


$bdd = new PDO('mysql:host=localhost;dbname=blog;charset=utf8;','root','');

}catch(Execption $e){
    die('il y a une erreur : '. $e->getMessage());
}
?>