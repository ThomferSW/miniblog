<?php 
session_start();

//l'utilisateurr valide le formulaire
if(isset($_POST['validate'])){

//vérification des données 
$checkIfALLImputsAreValids = !empty($_POST['pseudo']) AND !empty($_POST['password']);
if($checkIfALLImputsAreValids){
//admin par défaut 
$default_pseudo = 'admin';
$default_password = 'admin';
// donnée rentrés par l'utilisateur 
$user_pseudo = htmlspecialchars($_POST['pseudo']);
$user_password = htmlspecialchars($_POST['password']);

//vérification si les pseudos et mdp correspondent 
if($user_pseudo == $default_pseudo AND $user_password == $default_password){

//si oui, on rentre dans la session
    $_SESSION['auth'] = true;

    //retour page connexion 
    header('location: admin-interface.php');

}else{
    //si non on reste dehors !
    $errorMsg = "Votre pseudo ou mot de passe est iincorect";
}
}else{
    $errorMsg = 'Veuillez compléter tout les champs';
}


}



?>