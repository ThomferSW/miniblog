<?php

require('../database.php');
//si l'utilisateur n'est pas authentifié alors on le redirige vers la page de connexion 

if(!isset($_SESSION['auth'])){
 header('location: ../../login-admin.php');
}

//vérification que l'ID de l'article à bien été passé en parametre da,s l'URL 
if(isset($_GET['id']) AND !empty($_GET['id'])){

//identifiant de l'article récupéré 
        $idOfTheArticle = $_GET['id'];
//verifier si l'article existe dans la table des articles 
        $checkIfThisArticleExist = $bdd->prepare('SELECT id FROM articles WHERE id = ?');
        $checkIfThisArticleExist->execute(array($idOfTheArticle));

        if($checkIfThisArticleExist->rowCount() > 0){

            //suprimer l'article
            $deleteThisArticle = $bdd->prepare('DELETE FROM articles WHERE id = ?'); 
            $deleteThisArticle->execute(array($idOfTheArticle));

            //redirection de l'utilisateur vers la page de connexion 
            header('location: ../../admin-interface.php');

        }else{
            echo "Aucun article trouvé";
        };
}else{
    echo "Aucun article trouvé";
}

