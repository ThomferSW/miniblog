<?php 
require('actions/database.php');

if(isset($_GET['id']) AND !empty($_GET['id'])){

        $idOfTheArticle = $_GET['id'];

        $getInfosOfTheArticle = $bdd->prepare('SELECT titre, contenu FROM articles WHERE id = ?');
        $getInfosOfTheArticle->execute(array($idOfTheArticle)); 

        if($getInfosOfTheArticle->rowCount() > 0){

            $articleInfos = $getInfosOfTheArticle->fetch();

        }else{
            $errorMsg = "Aucun article trouvé";
        }

}else{
    $errorMsg = 'Aucun article trouvé';
}
?>