<?php 
require('actions/database.php');

//validation du formulraie
if(isset($_POST['validate'])){

//verification si les champs son remplis
$checkIfALLImputsAreValids = !empty($_POST['title']) AND !empty($_POST['content']);
    if($checkIfALLImputsAreValids){
        //données à faire passer dans la requette
        $article_title = htmlspecialchars($_POST['title']);
        $article_content = nl2br(htmlspecialchars($_POST['content']));
        $current_date = date("d/m/Y");
//insertion de l'article
        $insertArticleInDatabase = $bdd->prepare('INSERT INTO articles(titre, contenu, date_publication)VALUES(?, ?, ?)');
        $insertArticleInDatabase->execute(array($article_title, $article_content, $current_date));
//redirection page des articles 
        header('location: admin-interface.php');

    }

}


?>