<?php
require('actions/database.php');

$getAllArticlesOfWebsite = $bdd->query('SELECT id, titre, contenu, date_publication FROM articles ORDER BY id DESC');