<?php
require ('actions/admin_actions/security-action.php');
require ('actions/admin_actions/show-all-articles-action.php');
?>

<!DOCTYPE html>
<html lang="fr">
<?php include 'includes/head.php'; ?>
<body>
    <?php 
    include 'includes/navbar-admin.php';
    ?>
<br><br>
<section class="container">

        <?php 
            while($article = $getAllArticlesOfWebsite->fetch()){
                echo "
                    <div class='card'>
                        <div class='card-body'>
                            ".$article['titre']."
                            <hr/>
                            <a href='actions/admin_actions/delete-article-action.php?id=".$article['id']."'>
                        <button class='btn btn-danger'>
                            Supprimer
                        </button>
                        <a/>
                            <a href='edit-article-admin.php?id=".$article['id']."'>
                        <button class='btn btn-warning'>
                            Modifier
                        </button>
                        <a/>
                        </div>
                        <div class='card-footer'> 
                        Publié par Thomas le : ".$article['date_publication']."
                        </div>
                    </div>
                    <br>
                ";
            }
        ?>

</section>

</body>
</html>