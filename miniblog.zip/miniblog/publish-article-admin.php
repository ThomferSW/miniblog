<?php 
require('actions/admin_actions/security-action.php'); 
require('actions/admin_actions/publish-article-action.php'); 
?>
<!DOCTYPE html>
<html lang="fr">
<?php include ('includes/head.php');?>
<body>
    <?php include 'includes/navbar-admin.php'; ?>
<br><br>
<form class="container" method="POST">
  <div class="mb-3">
    <label class="form-label">Titre de l'article</label>
    <input type="text" class="form-control" name="title">
  </div>

  <div class="mb-3">
  <label class="form-label">Contenu de l'article</label>
  <textarea class="form-control" rows="3" name="content"></textarea>
</div>
  <button type="submit" class="btn btn-primary" name="validate">Publier l'article</button>
</form>

</body>
</html>