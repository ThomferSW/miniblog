<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Espace ADMIN</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="publish-article-admin.php">Publier un article</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="admin-interface.php">Afficher les articles</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="actions/admin_actions/logout-action.php">Déconnexion</a>
         </li>

      </ul>
    </div>
  </div>
</nav>